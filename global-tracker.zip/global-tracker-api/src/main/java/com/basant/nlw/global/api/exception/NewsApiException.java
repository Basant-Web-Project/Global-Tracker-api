package com.basant.nlw.global.api.exception;

public class NewsApiException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7345132077219237203L;

	public NewsApiException(String message) {
		super(message);
	}

}
